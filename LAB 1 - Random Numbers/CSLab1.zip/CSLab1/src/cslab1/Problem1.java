package cslab1;
import java.util.*;

//1. Generate 10 random numbers
public class Problem1 
{
    Random rand = new Random();
    
    //Function to generate an integer random number
    int randomNumber()  
    {  
       return(rand.nextInt());
    }
}
